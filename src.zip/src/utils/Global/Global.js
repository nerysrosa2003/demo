
export default {
	base_url: 'https://luis1.herokuapp.com',
    user_name: '',
    password: '',

    edit_case_json: null,
    visitStatus: '',
    editcase_page_title: 'Visit Master',
    procedure_selected_top_tab: 'Procedure'
}